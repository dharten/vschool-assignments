import React from "react";

import Main from "./fullWindow/Main";

export default function App() {
  return(
    <Main />
  )
}
