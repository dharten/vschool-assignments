import {combineReducers} from "redux";
import uglyThings from "./fullWindow/InputsReducer";

export default combineReducers({
  uglyThings
})
